import Setting from "../models/setting.model.js";
import { errorHandler } from "../utils/error.js";

export const getSetting = async (req, res, next) => {
  try {
    const { key } = req.params;
    const setting = await Setting.findOne({ key });
    if (!setting) {
      return res.status(200).json({ success: true, setting: null });
    }
    res.status(200).json({ success: true, setting });
  } catch (error) {
    next(error);
  }
};

export const getAllSettings = async (req, res, next) => {
  try {
    const settings = await Setting.find({});
    res.status(200).json({ success: true, settings });
  } catch (error) {
    next(error);
  }
};

export const updateSetting = async (req, res, next) => {
  if (!req.user.isAdmin) {
    return next(errorHandler(403, "You are not allowed to update settings"));
  }
  try {
    const { key } = req.params;
    const { value } = req.body;
    
    let setting = await Setting.findOne({ key });
    
    if (setting) {
      setting.value = value;
      await setting.save();
    } else {
      setting = new Setting({ key, value });
      await setting.save();
    }
    
    res.status(200).json({ success: true, setting });
  } catch (error) {
    next(error);
  }
};

export const deleteSetting = async (req, res, next) => {
  if (!req.user.isAdmin) {
    return next(errorHandler(403, "You are not allowed to delete settings"));
  }
  try {
    const { key } = req.params;
    await Setting.findOneAndDelete({ key });
    res.status(200).json({ success: true, message: "Setting deleted successfully" });
  } catch (error) {
    next(error);
  }
};
